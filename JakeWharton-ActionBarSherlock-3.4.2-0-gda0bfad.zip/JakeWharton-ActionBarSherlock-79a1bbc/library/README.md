ActionBarSherlock Library
=========================

This folder contains the main library which should be linked against as an
Android library project in your application.

For more information see the "Including In Your Project" section of the
[download page][1].






 [1]: http://actionbarsherlock.com/download.html
